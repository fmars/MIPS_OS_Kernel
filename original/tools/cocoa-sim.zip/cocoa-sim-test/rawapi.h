/* output a int value to simulator's console. */
extern void uput(unsigned int value);
