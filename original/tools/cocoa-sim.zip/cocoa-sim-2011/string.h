char * trim(char * buffer);
int str_start(char * buffer, int start);
int str_match(char * buffer, int (* test)(int));
