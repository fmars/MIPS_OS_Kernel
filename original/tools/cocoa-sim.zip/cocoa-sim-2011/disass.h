void disassemble(unsigned int inst);
