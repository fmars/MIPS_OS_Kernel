﻿(1)安装方法:

1) 
  > make 
2) 
  以root用户安装:
  > make install

(2)使用:
1)
flash编辑器:
  > cocoa-flash-ed
它默认编辑当前目录下的flash_image文件, 没有就自动创建.
启动后有帮助命令的提示

2)
模拟器:
  > cocoa-sim-debug
它也默认使用flash_image文件
提示符出现后输入'h'可以看帮助:可用的命令
