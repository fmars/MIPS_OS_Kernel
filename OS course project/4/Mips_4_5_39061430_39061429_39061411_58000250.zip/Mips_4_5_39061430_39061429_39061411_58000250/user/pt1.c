#include "lib.h"

umain()
{
	int i=0;

	for(i=0;i<100;i++)
		writef("1");

	return ;
}
