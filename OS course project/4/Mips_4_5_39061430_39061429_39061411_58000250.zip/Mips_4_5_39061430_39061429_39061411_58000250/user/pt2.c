#include "lib.h"

umain()
{
	for(;;)
		writef("2");

	return ;
}
