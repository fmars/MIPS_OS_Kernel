#include "lib.h"

umain()
{
	writef("idle is running\n");
	while(1)
		writef("2!");
}
